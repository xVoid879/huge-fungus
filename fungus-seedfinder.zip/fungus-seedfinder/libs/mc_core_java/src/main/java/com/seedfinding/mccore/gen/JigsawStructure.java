package com.seedfinding.mccore.gen;

public class JigsawStructure {
	public JigsawStructure() {

	}
}
