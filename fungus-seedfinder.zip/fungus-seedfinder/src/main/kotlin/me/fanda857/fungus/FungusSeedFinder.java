package me.fanda857.fungus;

import com.seedfinding.latticg.reversal.DynamicProgram;
import com.seedfinding.latticg.reversal.calltype.java.JavaCalls;
import com.seedfinding.latticg.util.LCG;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcreversal.ChunkRandomReverser;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.LongStream;

public class FungusSeedFinder {

    private static final MCVersion version = MCVersion.v1_16_5;

    public static List<Long> findDecorSeeds(int limit) {
        DynamicProgram dp = DynamicProgram.create(LCG.JAVA);
        dp.skip(32);
        dp.add(JavaCalls.nextInt(10).equalTo(9));
        dp.add(JavaCalls.nextInt(12).equalTo(0));
        dp.add(JavaCalls.nextFloat().greaterThanEqual(0.06f));
        dp.add(JavaCalls.nextInt(9).equalTo(8));

        List<Long> results = new ArrayList<>();
        LongStream stream = dp.reverse().parallel().map(seed -> seed ^ LCG.JAVA.multiplier);
        stream.filter(seed -> {
            synchronized (results) {
                if (results.size() >= limit) return false;
                results.add(seed);
                return false;
            }
        }).count(); // force execution

        return results;
    }

    public static List<Long> reverseDecorSeed(long seed) {
        long popSeed = ChunkRandomReverser.reverseDecoratorSeed(seed, 3, 8, version);
        return ChunkRandomReverser.reversePopulationSeed(popSeed, 0, 0, version);
    }

    public static void main(String[] args) {
        List<Long> decorSeeds = findDecorSeeds(10);
        for (long decorSeed : decorSeeds) {
            List<Long> worldSeeds = reverseDecorSeed(decorSeed);
            for (long seed : worldSeeds) {
                System.out.println(seed);
            }
        }
    }
}
