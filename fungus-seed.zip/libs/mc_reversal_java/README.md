[![Build Status](https://jenkins.seedfinding.com/buildStatus/icon?job=mc_java%2Fmc_reversal_java)](https://jenkins.seedfinding.com/job/mc_java/job/mc_reversal_java/)

# Minecraft Reversal

A dead simple library exposing utilities to reverse all Minecraft internal
hash functions in pure Java.

## Legal mentions
Licensed under MIT

Maintained by Neil and KaptainWutax.

NOT OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG.
